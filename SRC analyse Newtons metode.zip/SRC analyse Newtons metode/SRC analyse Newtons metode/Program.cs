﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SRC_analyse_Newtons_metode
{
    internal class Program
    {
        
        static double EPSILON = 0.0001f;

        // An example function whose solution
        // is determined using Bisection Method.
        // The function is x^3 - x^2 + 2
        static double func(double x)
        {
            return Math.Pow(x,3) - Math.Pow(x,2) + 2;
        }

        // Derivative of the above function
        // which is 3*x^x - 2*x
        static double derivFunc(double x)
        {
            return 3 * x * x - 2 * x;
        }

        // Function to find the root
        static void newtonRaphson(double x)
        {
            int count = 0;
            double h = func(x) / derivFunc(x);
            while (Math.Abs(h) >= EPSILON)
            {
                h = func(x) / derivFunc(x);

                // x(i+1) = x(i) - f(x) / f'(x)
                x = x - h;

                count++; 
            }

            Console.WriteLine("The value of the"
                        + " root is : "
                        + Math.Round(x * 100.0) / 100.0);
            Console.WriteLine("Iterations: " + count);
        }


        static void Main(string[] args)
        {
            double x0 = 10;
            newtonRaphson(x0);

            Console.ReadKey();
        }
    }
}
